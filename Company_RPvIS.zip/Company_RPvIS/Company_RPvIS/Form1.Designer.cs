﻿namespace Company_RPvIS
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnClientsChange = new System.Windows.Forms.Button();
            this.btnClientsDelete = new System.Windows.Forms.Button();
            this.btnClientsAdd = new System.Windows.Forms.Button();
            this.dgvClients = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnProductsChange = new System.Windows.Forms.Button();
            this.btnProductsDelete = new System.Windows.Forms.Button();
            this.btnProductsAdd = new System.Windows.Forms.Button();
            this.dgvProducts = new System.Windows.Forms.DataGridView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.btnContractsChange = new System.Windows.Forms.Button();
            this.btnContractsDelete = new System.Windows.Forms.Button();
            this.btnContractsAdd = new System.Windows.Forms.Button();
            this.dgvContracts = new System.Windows.Forms.DataGridView();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.dtpEnd = new System.Windows.Forms.DateTimePicker();
            this.dtpStart = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.button1 = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvClients)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProducts)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvContracts)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(13, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1216, 747);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btnClientsChange);
            this.tabPage1.Controls.Add(this.btnClientsDelete);
            this.tabPage1.Controls.Add(this.btnClientsAdd);
            this.tabPage1.Controls.Add(this.dgvClients);
            this.tabPage1.Location = new System.Drawing.Point(8, 39);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1200, 700);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Клиенты";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnClientsChange
            // 
            this.btnClientsChange.Location = new System.Drawing.Point(312, 641);
            this.btnClientsChange.Name = "btnClientsChange";
            this.btnClientsChange.Size = new System.Drawing.Size(300, 50);
            this.btnClientsChange.TabIndex = 3;
            this.btnClientsChange.Text = "Изменение";
            this.btnClientsChange.UseVisualStyleBackColor = true;
            this.btnClientsChange.Click += new System.EventHandler(this.btnClientsChange_Click);
            // 
            // btnClientsDelete
            // 
            this.btnClientsDelete.Location = new System.Drawing.Point(618, 641);
            this.btnClientsDelete.Name = "btnClientsDelete";
            this.btnClientsDelete.Size = new System.Drawing.Size(300, 50);
            this.btnClientsDelete.TabIndex = 2;
            this.btnClientsDelete.Text = "Удалить запись";
            this.btnClientsDelete.UseVisualStyleBackColor = true;
            this.btnClientsDelete.Click += new System.EventHandler(this.btnClientsDelete_Click);
            // 
            // btnClientsAdd
            // 
            this.btnClientsAdd.BackColor = System.Drawing.Color.Transparent;
            this.btnClientsAdd.Location = new System.Drawing.Point(6, 641);
            this.btnClientsAdd.Name = "btnClientsAdd";
            this.btnClientsAdd.Size = new System.Drawing.Size(300, 50);
            this.btnClientsAdd.TabIndex = 1;
            this.btnClientsAdd.Text = "Добавление";
            this.btnClientsAdd.UseVisualStyleBackColor = false;
            this.btnClientsAdd.Click += new System.EventHandler(this.btnClientsAddChange_Click);
            // 
            // dgvClients
            // 
            this.dgvClients.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvClients.Location = new System.Drawing.Point(6, 6);
            this.dgvClients.Name = "dgvClients";
            this.dgvClients.RowHeadersWidth = 82;
            this.dgvClients.RowTemplate.Height = 33;
            this.dgvClients.Size = new System.Drawing.Size(1188, 629);
            this.dgvClients.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btnProductsChange);
            this.tabPage2.Controls.Add(this.btnProductsDelete);
            this.tabPage2.Controls.Add(this.btnProductsAdd);
            this.tabPage2.Controls.Add(this.dgvProducts);
            this.tabPage2.Location = new System.Drawing.Point(8, 39);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1200, 700);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Товары";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnProductsChange
            // 
            this.btnProductsChange.Location = new System.Drawing.Point(312, 641);
            this.btnProductsChange.Name = "btnProductsChange";
            this.btnProductsChange.Size = new System.Drawing.Size(300, 50);
            this.btnProductsChange.TabIndex = 6;
            this.btnProductsChange.Text = "Изменение";
            this.btnProductsChange.UseVisualStyleBackColor = true;
            this.btnProductsChange.Click += new System.EventHandler(this.btnProductsChange_Click);
            // 
            // btnProductsDelete
            // 
            this.btnProductsDelete.Location = new System.Drawing.Point(618, 641);
            this.btnProductsDelete.Name = "btnProductsDelete";
            this.btnProductsDelete.Size = new System.Drawing.Size(300, 50);
            this.btnProductsDelete.TabIndex = 5;
            this.btnProductsDelete.Text = "Удалить запись";
            this.btnProductsDelete.UseVisualStyleBackColor = true;
            this.btnProductsDelete.Click += new System.EventHandler(this.btnProductsDelete_Click);
            // 
            // btnProductsAdd
            // 
            this.btnProductsAdd.BackColor = System.Drawing.Color.Transparent;
            this.btnProductsAdd.Location = new System.Drawing.Point(6, 641);
            this.btnProductsAdd.Name = "btnProductsAdd";
            this.btnProductsAdd.Size = new System.Drawing.Size(300, 50);
            this.btnProductsAdd.TabIndex = 4;
            this.btnProductsAdd.Text = "Добавление";
            this.btnProductsAdd.UseVisualStyleBackColor = false;
            this.btnProductsAdd.Click += new System.EventHandler(this.btnProductsAdd_Click);
            // 
            // dgvProducts
            // 
            this.dgvProducts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProducts.Location = new System.Drawing.Point(6, 6);
            this.dgvProducts.Name = "dgvProducts";
            this.dgvProducts.RowHeadersWidth = 82;
            this.dgvProducts.RowTemplate.Height = 33;
            this.dgvProducts.Size = new System.Drawing.Size(1188, 629);
            this.dgvProducts.TabIndex = 3;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.btnContractsChange);
            this.tabPage3.Controls.Add(this.btnContractsDelete);
            this.tabPage3.Controls.Add(this.btnContractsAdd);
            this.tabPage3.Controls.Add(this.dgvContracts);
            this.tabPage3.Location = new System.Drawing.Point(8, 39);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1200, 700);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Договоры";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // btnContractsChange
            // 
            this.btnContractsChange.Location = new System.Drawing.Point(312, 641);
            this.btnContractsChange.Name = "btnContractsChange";
            this.btnContractsChange.Size = new System.Drawing.Size(300, 50);
            this.btnContractsChange.TabIndex = 7;
            this.btnContractsChange.Text = "Изменение";
            this.btnContractsChange.UseVisualStyleBackColor = true;
            this.btnContractsChange.Click += new System.EventHandler(this.btnContractsChange_Click);
            // 
            // btnContractsDelete
            // 
            this.btnContractsDelete.Location = new System.Drawing.Point(618, 641);
            this.btnContractsDelete.Name = "btnContractsDelete";
            this.btnContractsDelete.Size = new System.Drawing.Size(300, 50);
            this.btnContractsDelete.TabIndex = 5;
            this.btnContractsDelete.Text = "Удалить запись";
            this.btnContractsDelete.UseVisualStyleBackColor = true;
            this.btnContractsDelete.Click += new System.EventHandler(this.btnContractsDelete_Click);
            // 
            // btnContractsAdd
            // 
            this.btnContractsAdd.BackColor = System.Drawing.Color.Transparent;
            this.btnContractsAdd.Location = new System.Drawing.Point(6, 641);
            this.btnContractsAdd.Name = "btnContractsAdd";
            this.btnContractsAdd.Size = new System.Drawing.Size(300, 50);
            this.btnContractsAdd.TabIndex = 4;
            this.btnContractsAdd.Text = "Добавление";
            this.btnContractsAdd.UseVisualStyleBackColor = false;
            this.btnContractsAdd.Click += new System.EventHandler(this.btnContractsAdd_Click);
            // 
            // dgvContracts
            // 
            this.dgvContracts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvContracts.Location = new System.Drawing.Point(6, 6);
            this.dgvContracts.Name = "dgvContracts";
            this.dgvContracts.RowHeadersWidth = 82;
            this.dgvContracts.RowTemplate.Height = 33;
            this.dgvContracts.Size = new System.Drawing.Size(1188, 629);
            this.dgvContracts.TabIndex = 3;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.dtpEnd);
            this.tabPage4.Controls.Add(this.dtpStart);
            this.tabPage4.Controls.Add(this.label2);
            this.tabPage4.Controls.Add(this.label1);
            this.tabPage4.Controls.Add(this.button2);
            this.tabPage4.Controls.Add(this.chart1);
            this.tabPage4.Controls.Add(this.button1);
            this.tabPage4.Location = new System.Drawing.Point(8, 39);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1200, 700);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Диаграмма/отчёты";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // dtpEnd
            // 
            this.dtpEnd.Location = new System.Drawing.Point(55, 138);
            this.dtpEnd.Name = "dtpEnd";
            this.dtpEnd.Size = new System.Drawing.Size(336, 31);
            this.dtpEnd.TabIndex = 6;
            // 
            // dtpStart
            // 
            this.dtpStart.Location = new System.Drawing.Point(55, 49);
            this.dtpStart.Name = "dtpStart";
            this.dtpStart.Size = new System.Drawing.Size(336, 31);
            this.dtpStart.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(50, 110);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(164, 25);
            this.label2.TabIndex = 4;
            this.label2.Text = "Конец периода";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(50, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(176, 25);
            this.label1.TabIndex = 3;
            this.label1.Text = "Начало периода";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(118, 469);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(200, 70);
            this.button2.TabIndex = 2;
            this.button2.Text = "Диаграмма";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // chart1
            // 
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(448, 34);
            this.chart1.Name = "chart1";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.chart1.Series.Add(series1);
            this.chart1.Size = new System.Drawing.Size(715, 640);
            this.chart1.TabIndex = 1;
            this.chart1.Text = "chart1";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(118, 352);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(200, 70);
            this.button1.TabIndex = 0;
            this.button1.Text = "Сформировать отчёт";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1274, 779);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "БД компания вариант 9";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvClients)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvProducts)).EndInit();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvContracts)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.DataGridView dgvClients;
        private System.Windows.Forms.Button btnClientsAdd;
        private System.Windows.Forms.Button btnClientsDelete;
        private System.Windows.Forms.Button btnProductsDelete;
        private System.Windows.Forms.Button btnProductsAdd;
        private System.Windows.Forms.DataGridView dgvProducts;
        private System.Windows.Forms.Button btnContractsDelete;
        private System.Windows.Forms.Button btnContractsAdd;
        private System.Windows.Forms.DataGridView dgvContracts;
        private System.Windows.Forms.Button btnClientsChange;
        private System.Windows.Forms.Button btnProductsChange;
        private System.Windows.Forms.Button btnContractsChange;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.DateTimePicker dtpEnd;
        private System.Windows.Forms.DateTimePicker dtpStart;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button2;
    }
}

