﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using System.Windows.Forms.VisualStyles;
using Microsoft.Office.Interop.Excel;
using Npgsql;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using DataTable = System.Data.DataTable;
using Excel = Microsoft.Office.Interop.Excel;
using Series = System.Windows.Forms.DataVisualization.Charting.Series;


namespace Company_RPvIS
{
    public partial class Form1 : Form
    {
        private NpgsqlConnection con;
        private string conString =
            "Host = 127.0.0.1; Username = postgres; Password = 123; Database = company_project";
        public Form1()
        {
            InitializeComponent();
            con = new NpgsqlConnection(conString);
            con.Open();

            loadClients();
            loadProducts();
            loadContracts();
        }

        private void loadClients()
        {
            DataTable dt = new DataTable();
            NpgsqlDataAdapter adap = new NpgsqlDataAdapter("SELECT * FROM clients", con);
            adap.Fill(dt);
            dgvClients.DataSource = dt;
        }

        private void loadProducts()
        {
            
            DataTable dt = new DataTable();
            NpgsqlDataAdapter adap = new NpgsqlDataAdapter("SELECT * FROM products", con);
            adap.Fill(dt);
            dgvProducts.DataSource = dt;
        }

        private void loadContracts()
        {

            DataTable dt = new DataTable();
            NpgsqlDataAdapter adap = new NpgsqlDataAdapter("SELECT * FROM contracts", con);
            adap.Fill(dt);
            dgvContracts.DataSource = dt;
        }

        private void btnClientsAddChange_Click(object sender, EventArgs e)
        {
            FormAddClients f = new FormAddClients();
            f.ShowDialog();
            loadClients();
        }

        private void btnClientsChange_Click(object sender, EventArgs e)
        {
            FormChangeClients f = new FormChangeClients();
            f.ShowDialog();
            loadClients();
        }

        private void btnClientsDelete_Click(object sender, EventArgs e)
        {
            string sql = $"DELETE FROM clients WHERE id=(@id)";
            NpgsqlCommand cmd = new NpgsqlCommand(sql, con);
            int id = int.Parse(dgvClients.CurrentRow.Cells[0].Value.ToString());
            cmd.Parameters.AddWithValue("id", id);
            cmd.Prepare();
            cmd.ExecuteNonQuery();

            loadClients();
        }

        private void btnProductsDelete_Click(object sender, EventArgs e)
        {
            string sql = $"DELETE FROM products WHERE id=(@id)";
            NpgsqlCommand cmd = new NpgsqlCommand(sql, con);
            int id = int.Parse(dgvProducts.CurrentRow.Cells[0].Value.ToString());
            cmd.Parameters.AddWithValue("id", id);
            cmd.Prepare();
            cmd.ExecuteNonQuery();

            loadProducts();
        }

        private void btnProductsAdd_Click(object sender, EventArgs e)
        {
            FormAddProducts f = new FormAddProducts();
            f.ShowDialog();
            loadProducts();
        }

        private void btnProductsChange_Click(object sender, EventArgs e)
        {
            FormChangeProducts f = new FormChangeProducts();
            f.ShowDialog();
            loadProducts();
        }

        private void btnContractsDelete_Click(object sender, EventArgs e)
        {
            string sql = $"DELETE FROM contracts WHERE id=(@id)";
            NpgsqlCommand cmd = new NpgsqlCommand(sql, con);
            int id = int.Parse(dgvContracts.CurrentRow.Cells[0].Value.ToString());
            cmd.Parameters.AddWithValue("id", id);
            cmd.Prepare();
            cmd.ExecuteNonQuery();

            loadContracts();
        }

        private void btnContractsAdd_Click(object sender, EventArgs e)
        {
            FormAddContracts f = new FormAddContracts();
            f.ShowDialog();
            loadContracts();
        }

        private void btnContractsChange_Click(object sender, EventArgs e)
        {
            FormChangeContracts f = new FormChangeContracts();
            f.ShowDialog();
            loadContracts();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql1 = "SELECT id, name FROM products";
            NpgsqlCommand cmd1 = new NpgsqlCommand(sql1, con);
            
            Excel.Application ex = new Excel.Application();
            Workbook wb = ex.Workbooks.Open("C:/Users/Елизавета/Documents/Универ разное/РПвИС/list1.xlsx");
            Worksheet sheet = wb.Sheets[1];

            sheet.Cells[1, 1].Value = "Номер договора";
            sheet.Cells[1, 2].Value = "Наименование товара";
            sheet.Cells[1, 3].Value = "Количество товара";
            sheet.Cells[1, 4].Value = "Сумма";

            string ProductName = "";
            DateTime d1 = dtpStart.Value;
            DateTime d3 = dtpEnd.Value;
            int countRows = 2;

            for (int i = 0; i < dgvContracts.Rows.Count; i++)
                if (Convert.ToBoolean(dgvContracts.Rows[i].Cells[7].Value) == false && Convert.ToDateTime(dgvContracts.Rows[i].Cells[3].Value) >= d1 && Convert.ToDateTime(dgvContracts.Rows[i].Cells[3].Value) <= d3)
                {
                    NpgsqlDataReader reader1 = cmd1.ExecuteReader();
                    while (reader1.Read())
                    {
                        //comboBoxTour.Items.Add(reader.GetString(0));
                        if (dgvContracts.Rows[i].Cells[2].Value.ToString() == reader1.GetValue(0).ToString())
                        {
                            ProductName = reader1.GetString(1);
                        }
                    }
                    reader1.Close();

                    sheet.Cells[countRows, 1].Value = dgvContracts.Rows[i].Cells[0].Value;
                    sheet.Cells[countRows, 2].Value = ProductName;
                    sheet.Cells[countRows, 3].Value = dgvContracts.Rows[i].Cells[4].Value;
                    sheet.Cells[countRows, 4].Value = dgvContracts.Rows[i].Cells[5].Value;
                    countRows++;
                }

            sheet.Rows[1].Style.HorizontalAlignment = HorizontalAlignment.Center;
            sheet.Rows[1].Style.VerticalAlignment = VerticalAlignment.Center;
            sheet.Cells.WrapText = true;
            ex.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            chart1.Series.Clear();
            DateTime d1 = dtpStart.Value;
            DateTime d3 = dtpEnd.Value;

            int countKontr = 0;
            int countOtgr = 0;

            for (int i = 0; i < dgvContracts.Rows.Count; i++)
                if (Convert.ToDateTime(dgvContracts.Rows[i].Cells[3].Value) >= d1 && Convert.ToDateTime(dgvContracts.Rows[i].Cells[3].Value) <= d3)
                {
                    if (Convert.ToBoolean(dgvContracts.Rows[i].Cells[7].Value) == true)
                        countOtgr += Convert.ToInt32(dgvContracts.Rows[i].Cells[4].Value);
                    else
                        countKontr += Convert.ToInt32(dgvContracts.Rows[i].Cells[4].Value);
                }

            //label3.Text = countOtgr.ToString();
            //label4.Text = countKontr.ToString();
            Series s1 = chart1.Series.Add("S1");
            s1.ChartType = SeriesChartType.Pie;

            s1.Points.AddXY("Отгруженные", Convert.ToString(countOtgr));
            s1.Points.AddXY("Законтрактованные", Convert.ToString(countKontr));



        }
    }
}

